﻿Namespace MonitoringDatabase
    Public Class Users
        Public Property UserID As Int32
        Public Property UserName As String
        Public Property Password As String
        Public Property EmailAddress As String
        Public Property UserRole As String
        Public Property FirstName As String
        Public Property LastName As String
        Public Property LastModified As Date?
    End Class
End Namespace