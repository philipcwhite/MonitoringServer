﻿Namespace MonitoringDatabase
    Public Class ServerConfiguration
        Public Property ConfigID As Int32
        Public Property Name As String
        Public Property Value As String
    End Class
End Namespace