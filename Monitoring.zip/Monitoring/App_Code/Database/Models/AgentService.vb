﻿Namespace MonitoringDatabase
    Public Class AgentService
        Public Property AgentID As Int64
        Public Property AgentName As String
        Public Property AgentClass As String
        Public Property AgentProperty As String
        Public Property AgentValue As Int16
        Public Property AgentCollectDate As Date? = Nothing
    End Class
End Namespace