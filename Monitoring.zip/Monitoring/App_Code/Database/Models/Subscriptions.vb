﻿Namespace MonitoringDatabase
    Public Class Subscriptions
        Public Property SubscriptionID As Int32
        Public Property AgentName As String
        Public Property UserName As String
        Public Property Notify As Boolean
    End Class
End Namespace