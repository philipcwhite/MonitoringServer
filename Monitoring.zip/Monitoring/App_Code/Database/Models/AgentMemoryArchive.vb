﻿Namespace MonitoringDatabase
    Public Class AgentMemoryArchive
        Public Property AgentID As Int64
        Public Property AgentName As String
        Public Property AgentClass As String
        Public Property AgentProperty As String
        Public Property AgentValue As Double
        Public Property AgentCollectDate As Date? = Nothing
    End Class
End Namespace