﻿Namespace MonitoringDatabase
    Public Class GlobalThresholds
        Public Property ThresholdID As Int32
        Public Property AgentClass As String
        Public Property AgentProperty As String
        Public Property Comparison As String
        Public Property ThresholdValue As Int32
        Public Property ThresholdTime As Int32
        Public Property Severity As Int32
        Public Property Enabled As Boolean
    End Class
End Namespace

