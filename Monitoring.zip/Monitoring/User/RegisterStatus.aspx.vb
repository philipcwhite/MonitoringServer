﻿
Partial Class User_RegisterStatus
    Inherits System.Web.UI.Page

End Class
