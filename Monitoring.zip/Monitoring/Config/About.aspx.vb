﻿
Partial Class Config_About
    Inherits System.Web.UI.Page

End Class
